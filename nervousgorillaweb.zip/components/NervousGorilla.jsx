import React from "react";

const NervousGorilla = () => {
  return (
    <div className="py-5" data-aos="fade-up" data-aos-duration="2000">
      <div className="container">
        <h1 className="text-center pb-4 main-heading kanit-font-family ">
          FRANTIC FROG TEAM
        </h1>
        <div className="d-flex justify-content-center">
          <p
            className="text-center small-text opacity-07 max-width-975 montserrat-font-family"
            id="gallery"
          >
            Frantic Frog is a collection of 10,000 unique Frantic Frog NFTs featuring Frankie, The Frantic Frog amiably known in the community as F Cube.
            Glide and slippity slide into the NFT tide.  <br /> <br />Come along for the ride and join the F Cube frantic side. <br /> <br /> Frantic Frogs
            are NFTs-digital collectibles stored as ERC-721 tokens on the
            Polygon blockchain and hosted on an interplanetary file system
            (IPFS).
          </p>
        </div>
      </div>
    </div>
  );
};

export default NervousGorilla;
